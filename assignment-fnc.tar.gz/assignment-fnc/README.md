This is my attempt at the Fake News Challenge.

Original utility functions and data were sourced from:
https://github.com/FakeNewsChallenge/fnc-1-baseline
